[LPC] Victorian Town Preview

IMPORTANT: The files in this directory are derived from several submissions on OpenGameArt. If you use any files in this directory, you MUST attribute ALL ORIGINAL AUTHORS of the files you use---NOT just bluecarrot16 and NOT just the authors listed on https://opengameart.org/content/lpc-victorian-town-decorations . 

https://opengameart.org/content/lpc-roofs
https://opengameart.org/content/lpc-containers
https://opengameart.org/content/lpc-food
https://opengameart.org/content/lpc-bricks
https://opengameart.org/content/lpc-terrains
https://opengameart.org/content/lpc-trees
https://opengameart.org/content/lpc-windows-doors
https://opengameart.org/content/lpc-victorian-buildings
https://opengameart.org/content/lpc-victorian-town-decorations

All images in this directory are available under a **CC-BY-SA 4.0** license. Other licenses may be available---see the original submissions. 

If you use any files in this directory, you must include ALL information in `CREDITS-*.txt` for that file in your final work. That means if you distribute any image in this file, you must distribute the coresponding `CREDITS-*.txt` file alongside it (or the information therein).

The license for the .tsx and .tmx file(s) in this directory is CC0. This refers to the Tiled XML data ONLY, NOT the .png images. 
